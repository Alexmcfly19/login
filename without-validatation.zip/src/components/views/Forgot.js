import { useState } from "react";
import { Link } from "react-router-dom";
import Form from '../../utilities/Forms'

const Forgot = () => {

    const [email, setEmail] = useState('');
    

    const forgotPassword = (e) => {
        e.preventDefault();


        if (1) {
            alert('Reset password link is sent to '+email);
            setEmail('');
        }
    }

    return (
        <div className="row g-0 auth-wrapper">
            <div className="col-12 col-md-5 col-lg-6 h-100 auth-background-col">
                <div className="auth-background-holder"></div>
                <div className="auth-background-mask"></div>
            </div>

            <div className="col-12 col-md-7 col-lg-6 auth-main-col text-center">
                <div className="d-flex flex-column align-content-end">
                    <div className="auth-body mx-auto">
                        <div className="auth-form-container text-start">
                            <form className="auth-form" method="POST" onSubmit={forgotPassword} autoComplete={'off'} dir='rtl'>
                                <div className="email mb-3">
                                    <input type="email"
                                        className={`form-control`}
                                        id="email"
                                        name="email"
                                        value={email}
                                        placeholder="ایمیل"
                                        onChange={(e) => setEmail(e.target.value)}
                                    />

                                
                                </div>
                                
                                <div className="text-center">
                                    <button type="submit" className="btn btn-primary w-100 theme-btn mx-auto">فراموشی رمز عبور</button>
                                </div>
                            </form>

                            <hr />
                            <div className="auth-option text-center pt-2"><Link className="text-link" to="/login" >بازگشت به صفحه ورود</Link></div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    );
}

export default Forgot;