import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Login from "./components/views/Login";
import Forgot from "./components/views/Forgot";
import './index.css'
const Auth = () => {
  return (
    <Router>
      <Switch>
        <Route path='/login' component={Login} />
        <Route path='/forgot-password' component={Forgot} />
        <Route path='/' component={Login} />
      </Switch>
    </Router>
  );
}

export default Auth;
